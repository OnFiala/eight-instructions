8 Instructions — Build004 native reproduction

Requires Node.js22+. No npm install, network, backend or API key.
Run: node tools/replay.mjs dist/reproduction/build-004.json
The CLI checks artifact hashes, restores a new BF machine for each branch,
feeds the recorded inputs and compares every expected native output byte.
The included gzip kernel is actual BF, not host application code.
Expected output is evidence only. Source and interpreter identities are in the JSON.

Interactive snapshot: node runtime/cli.mjs --load dist/initial-industry.8i
Cold boot: node runtime/cli.mjs --autonomous --fuel 2e14 --blocks 3e10

Original repository: https://github.com/OnFiala/eight-instructions
